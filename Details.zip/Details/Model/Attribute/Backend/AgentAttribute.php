<?php 

namespace Employee\Details\Model\Attribute\Backend;

use Magento\Catelog\Model\Product;
use Magento\Eav\Model\Entity\Attribute\Backend\AbstractBackend;
use Magento\Framework\Exception\LocalizedException;

class AgentAttribute extends AbstractBackend
{
    public function validate($object)
    {
        
    }
}
